#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(0, 0, 0);
	
	ofEnableSmoothing();
	
	numCirclesHorizontal = 21;
	numCirclesVertical   = 16;
	
	gridSize = 40;
	
	ofSetFrameRate(25);
}

//--------------------------------------------------------------
void testApp::update(){

}

//--------------------------------------------------------------
void testApp::draw(){
		
	for (int i = 0; i < numCirclesHorizontal; i++) {
		for (int j = 0; j < numCirclesVertical; j++) {
			
			float r = ofRandom(0, 255);
			float g = ofRandom(0, 128);
			float b = ofRandom(128, 255);
			
			radius = ofRandom(10, 20);
			
			ofSetColor(r, g, b);
			ofFill();
			ofCircle(i*gridSize, j*gridSize, radius);
			ofNoFill();
			ofCircle(i*gridSize, j*gridSize, radius);
			
		}
	}
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

