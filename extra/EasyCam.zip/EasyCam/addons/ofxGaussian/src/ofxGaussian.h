#ifndef OFXGAUSSIAN_H
#define OFXGAUSSIAN_H

#include "ofMain.h"

float ofxGaussian();

#endif // OFXGAUSSIAN_H
